import sqlite3


def increase_cr(cr: float) -> float:
    """ The purpose of this function is to manually go up the D&D 5e "Monster Statistics by Challenge Rating" table
        Because the smallest values go from 0 to 1/8 to 1/4 to 1/2 to 1, simple math is not able to be used, thus
        this brute method is used.
    :param cr: the challenge rating provided, which represents the CR of the monster before the increase
    :return: the next value on the table, which is either the next appropriate fraction or the given CR + 1
    """
    if cr == 0.0:
        return 0.125
    elif cr == 0.125:
        return 0.25
    elif cr == 0.25:
        return 0.5
    elif cr == 0.5:
        return 1.0
    else:
        return cr + 1.0


def decrease_cr(cr: float) -> float:
    """ The purpose of this function is to manually go down the D&D 5e "Monster Statistics by Challenge Rating" table
        Because the smallest values go from 0 to 1/8 to 1/4 to 1/2 to 1, simple math is not able to be used, thus
        this brute method is used.
    :param cr: the challenge rating provided, which represents the CR of the monster before the decrease
    :return: the next value on the table, which is either the next appropriate fraction or the given CR - 1
    """
    if cr > 1:
        return cr - 1
    elif cr == 1:
        return 0.5
    elif cr == 0.5:
        return 0.25
    elif cr == 0.25:
        return 0.125
    elif cr == 0.125:
        return 0.0
    else:
        return 0.0


def find_cr(hp_or_dmg: int, search_for: str) -> float:
    """
    The purpose of this function is to find the CR of the monster only in respect to its hit points or average damage
    :param hp_or_dmg: the value the monster uses, which is compared to the minimum and maximum value of CR of the rows
    :param search_for: whether the function is being used to search for hit points or average damage
    :return: the CR of the monster based purely on hit point or average damage values
    """
    # connect to database
    db = sqlite3.connect("CRTable.sqlite")
    cursor = db.cursor()

    found = False  # used to stop the while loop below when the desired CR is found
    challenge_rating, min_num, max_num, lower_val, upper_val = 0, 0, 1, " ", " "

    if search_for == "hp":
        lower_val = "hitPointMin"
        upper_val = "hitPointMax"
    else:
        lower_val = "avgDmgMin"
        upper_val = "avgDMgMax"

    while found is False and challenge_rating <= 30:
        # Pull hit point maximum and minimum values from database row where CR is equal to current challenge rating
        execute_statement = "SELECT {}, {} FROM CRTable WHERE CR={}".format(lower_val, upper_val, challenge_rating)
        cursor.execute(execute_statement)
        for smaller, bigger in cursor:
            min_num = smaller
            max_num = bigger
        # if provided hit points is between or equal to values, CR desired is found
        if min_num <= hp_or_dmg <= max_num:
            found = True
        # if it is not between or equal to the values, go to the next row
        else:
            challenge_rating = increase_cr(challenge_rating)

    cursor.connection.close()
    db.close()

    return challenge_rating


def adjust_cr(challenge_rating: float, ac_or_hit_or_dc: int, search_for: str) -> float:
    """
    The purpose of this function is to adjust the CR value provided based on either its AC, hit bonus, or save DC value
    :param challenge_rating: the challenge rating before it is adjusted
    :param ac_or_hit_or_dc: the value used to determine if adjustment is necessary, and by how much
    :param search_for: whether the function is to adjust based on AC, hit bonus, or save DC
    :return: the new CR after being adjusted (which may be the same as the original)
    """
    db = sqlite3.connect("CRTable.sqlite")
    cursor = db.cursor()

    cursor.execute("SELECT {} FROM CRTable WHERE CR={}".format(search_for, challenge_rating))

    comp_val = 0

    for compare_value in cursor:
        comp_val = compare_value[0]

    if comp_val < ac_or_hit_or_dc:  # If the AC, hit, or dc in the chart is less than the value of the monster
        adjust_val = ((ac_or_hit_or_dc - comp_val) // 2)  # we only care if it is 2 or more higher
    elif comp_val > ac_or_hit_or_dc:  # if the AC, hit, or dc in the chart is greater than the value of the monster
        adjust_val = ((comp_val - ac_or_hit_or_dc) // 2)  # we only care if it is 2 or more lower
    else:  # if they are the same
        adjust_val = 0

    # for every 2 values the two values are different, the CR is pushed up or down the table by 1
    while adjust_val > 0:
        if ac_or_hit_or_dc > comp_val:  # challenge rating is increasing
            challenge_rating = increase_cr(challenge_rating)
        if comp_val > ac_or_hit_or_dc:  # challenge rating is decreasing
            challenge_rating = decrease_cr(challenge_rating)
        adjust_val = adjust_val - 1

    cursor.connection.close()
    db.close()

    return challenge_rating


def calc_final_cr(off_cr: float, def_cr: float) -> float:
    """
    The purpose of this function is to find the final CR of the monster based on the already calculated offensive CR
    and defensive CR of the monster
    A monster's final CR is the average row between them. For example, if the off_cr is 3 and the def_cr is 1, the
    final cr would be 2. However, if there is no perfect middle, we take the higher of the two while touching. As such,
    an off_cr of 5 and def_cr of 2 would be 4, not 3.
    Because of the possibility of fractional CRs, we can't perform simple math when a CR is a fraction. As such, we
    first look to see if the CRs are the same. If not, we then check if increasing the smaller one on the chart would
    make them the same. If yes, take the higher value. If no, they are far enough apart to be brought one row closer to
    each other, and then the test repeats.
    :param off_cr: the monster's offensive CR
    :param def_cr: the monster's defensive CR
    :return: the final cr of the monster
    """
    answer = 0

    if off_cr < 1 or def_cr < 1:  # one or both of the CRs is a fraction, and thus a special case
        # it is easier to do the process when we know which is smaller and which is bigger
        min_val = min(off_cr, def_cr)
        max_val = max(off_cr, def_cr)
        # while the two are not the same and incrementing the smaller value does not cause them to be the same
        while not min_val == max_val and not increase_cr(min_val) == max_val:
            min_val = increase_cr(min_val)
            max_val = decrease_cr(max_val)
        answer = max_val  # if the while loop is satisfied, max_val will always be the appropriate value
    else:  # if both values are 1 or more, simply find the average of the two and round up
        answer = (def_cr + off_cr + (def_cr % off_cr)) // 2.0

    return answer


def calc_cr(avg_hp: int, eff_ac: int, avg_dmg: int, eff_atk_or_dc: int, hit_or_dc: str) -> float:
    """
    The purpose of this function is to take the 4 values used to calculate a monster's CR and calculate the offensive
    and defensive CR. It can then call the calc_final_cr function to get the monster's final CR value
    :param avg_hp: monster's average hit points
    :param eff_ac: monster's armor class
    :param avg_dmg: monster's average damage per round
    :param eff_atk_or_dc: monster's hit bonus or save dc
    :param hit_or_dc: whether the monster is using hit bonus or dc for calculations
    :return: the final CR of the monster
    """
    # determine the defensive CR by using the "find_cr_from_hp and the adjust_cr_from_ac function
    def_cr = adjust_cr(find_cr(avg_hp, "hp"), eff_ac, "armorClass")
    if hit_or_dc == "dc":
        off_cr = adjust_cr(find_cr(avg_dmg, "dmg"), eff_atk_or_dc, "saveDC")
    else:
        # determine the offensive CR by using the "find_cr_from_dmg and the adjust_cr_from_atk function
        off_cr = adjust_cr(find_cr(avg_dmg, "dmg"), eff_atk_or_dc, "hitBonus")
    return calc_final_cr(off_cr, def_cr)


if __name__ == '__main__':
    # prompt user for 4 values that make up a monster's CR (and check for valid inputs)
    hp, ac, dmg, hit, dc = 0, 0, 0, 0, 0
    while hp <= 0 or hp > 850:
        hp = int(input("Please provide an HP value between 0 and 850: "))

    while ac <= 0 or ac > 30:
        ac = int(input("Please provide an AC value between 0 and 30: "))

    while dmg <= 0 or dmg > 320:
        dmg = int(input("Please provide an Average Damage value between 0 and 320: "))

    # a monster can be calculated using it's hit bonus or the DC of the saves it forces other to make
    # this section prompts to user to say which is more applicable and then ask for that
    hit_or_ac = input("Are you using the monster's attack bonus or its save dc? (type hit or dc) ")
    while not hit_or_ac.upper() == "HIT" and not hit_or_ac.upper() == "DC":
        hit_or_ac = input("Please type hit or dc: ")
    if hit_or_ac.upper() == "HIT":
        while hit <= 0 or hit > 30:
            hit = int(input("Please provide a Hit value between 0 and 30: "))

        print("HP: {} *** AC: {} *** DMG: {} *** Hit: {}".format(hp, ac, dmg, hit))

        result = calc_cr(hp, ac, dmg, hit, "hit")
        if result >= 1:
            print("CR: {}".format(int(result)))
        else:
            print("CR: {:.3f}".format(result))
    else:
        while dc <= 0 or dc > 30:
            dc = int(input("Please provide a DC value between 0 and 30: "))

        print("HP: {} *** AC: {} *** DMG: {} *** Save DC: {}".format(hp, ac, dmg, dc))

        result = calc_cr(hp, ac, dmg, dc, "dc")
        if result >= 1:
            print("CR: {}".format(int(result)))
        else:
            print("CR: {:.3f}".format(result))
