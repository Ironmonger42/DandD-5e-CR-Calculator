To run the program, execute monster_main.py. You will then be prompted with what you would like to do:
- Make a new monster
- Load an existing monster
- Quit

If you make a new monster, you will be prompted for certain information, such as (but not limited to):
- Name
- creature type
- creature alignment
- Armor Class and AC calculation method (if applicable)